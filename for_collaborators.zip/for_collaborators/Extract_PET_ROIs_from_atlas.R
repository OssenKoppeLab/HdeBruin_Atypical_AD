# extract ROI-based values from a 3D nifti file (e.g. PET) and apply a grey matter mask to the atlas
# required input files are full paths to 3D nifti files, all images must be in the same space (i.e. MNI) and resolution
# e.g.
# path_to_pet = "/tmp/folder/pet.nii.gz" (should be a tau-PET file in MNI space)
# path_to_atlas = "/tmp/folder/atlas.nii.gz" (should be the Schaefer 200 ROI atlas)
# path_to_mask = "/tmp/folder/mask.nii.gz" (should be a sample-specific grey matter mask to restrict the Schaefer atlas)
# the function returns a data frame with 1 row and n columns corresponding to the number of ROIs in the atlas
#
# the function is used as follows
# pet_extracted = extract_Schaefer_ROIs(path_to_pet = "/tmp/folder/pet.nii.gz", path_to_atlas = "/tmp/folder/atlas.nii.gz", path_to_mask = "/tmp/folder/mask.nii.gz")
# an example for how to use the function using example data is attached

require(neurobase)
require(oro.nifti)
require(plyr)
require(dplyr)
require(tidyr)

# define the function
extract_Schaefer_ROIs <- function(path_to_pet, path_to_atlas, path_to_mask){
  # load files
  atlas_readin = neurobase::readnii(path_to_atlas)
  pet_readin = neurobase::readnii(path_to_pet)
  mask_readin = neurobase::readnii(path_to_mask)
  atlas_readin_masked = atlas_readin * mask_readin
  
  # reshape 3D nifti files to data frames
  tmp.df = 
    data.frame(atlas = as.numeric(atlas_readin_masked),
               nifti = as.numeric(pet_readin)) %>% 
    subset(atlas !=0)
  
  
  
  # extract mean 
  tmp.summary <- 
    tmp.df %>% 
    group_by(atlas) %>% 
    summarise(mean = mean(nifti, na.rm = T))
  
  # summarize mean ROI values
  tmp.summary.df <- data.frame(tmp.summary)
  #tmp.summary.df$atlas <- paste0("ROI_", tmp.summary.df$atlas)
  
  tmp.summary.df.wide = spread(tmp.summary.df, key = atlas, value = mean)
  
  return(tmp.summary.df.wide)
  
}


####  Example run - single subject #####
# Here's a short example how to extract data from a single PET image
# First define the paths to the mask and atlas file

# replace the data directory with the directory in which you have stored the data that was sent with this script
data_dir = "/Volumes/Users/nfranzme/R_Projects/Tau_spreading/Tau_atypical_AD/for_collaborators/"

mask = Sys.glob(file.path(data_dir, "/ROIs/GM_mask.nii.gz"))
atlas = Sys.glob(file.path(data_dir, "/ROIs/Schaefer2018_200Parcels.nii.gz"))
subject_PET = Sys.glob(file.path(data_dir, "/example_data/sub-01_ses-date_pet-AV1451_MNI_2mm_INFCER_SUVR.nii.gz"))

PET_Schaefer_single_sub = extract_Schaefer_ROIs(path_to_pet = subject_PET, path_to_atlas = atlas, path_to_mask = mask)
print(PET_Schaefer_single_sub)

# the PET data is now stored in a data frame called "PET_Schaefer_single_sub", 
# which has one row (i.e. one subject) and 200 columns (i.e. 200 ROIs within the atlas)


####  Example run - group of subjects #####
# Here's a short example how to extract data from a group of PET images
# First define the paths to the mask and atlas file

# replace the data directory with the directory in which you have stored the data that was sent with this script
data_dir = "/Volumes/Users/nfranzme/R_Projects/Tau_spreading/Tau_atypical_AD/for_collaborators/"

mask = Sys.glob(file.path(data_dir, "/ROIs/GM_mask.nii.gz"))
atlas = Sys.glob(file.path(data_dir, "/ROIs/Schaefer2018_200Parcels.nii.gz"))


# then we need to define a list of subject-level PET images defined as a 
# character vector. This list should include the full paths to all images that you would like to read in


multi_subject_PET = Sys.glob(file.path(data_dir, "/example_data/sub-*_pet-AV1451_MNI_2mm_INFCER_SUVR.nii.gz"))

# you can see that we have now included all three PET example images in a single character vector
print(multi_subject_PET)

# now, we need to extract the PET data for each subject in a loop

for (i in 1:length(multi_subject_PET)){
  if (i == 1){n = 1}
  if (i > 1){n = n + 1}
  
  # select your PET image
  current_PET = multi_subject_PET[i]
  print(paste0("processing image no: ", current_PET))
  
  # extract the data
  PET_tmp = extract_Schaefer_ROIs(path_to_pet = current_PET, path_to_atlas = atlas, path_to_mask = mask)
  PET_tmp$image = current_PET
  # compile in one data frame
  if (n == 1){PET_Schaefer_multi_sub = PET_tmp}
  if (n > 1){PET_Schaefer_multi_sub = rbind(PET_Schaefer_multi_sub, PET_tmp)}
  
}


# all PET data is now stored in a signle data frame called "PET_Schaefer_multi_sub", 
# which has three rows (i.e. three subjects) and 201 columns 
# (i.e. 200 ROIs within the atlas plus the path to the image in the last column)



